ALTER TABLE `threads` ADD `draft` text;
